% czt_1d(xin , scalx , scaled , d)
% 
% Chirp z transform along a single direction d of an ND array `xin` into the ND array 'xout'.
% Note that xin and xout can be the same array for inplace operations.
% This code is based on a 2D Matlab version of the CZT, written by H. Gross et al.
%     
% References: Rabiner, Schafer, Rader, The Cirp z-Transform Algorithm, IEEE Trans AU 17(1969) p. 86

function xout = czt_1d(xin, scaled, d)

    sz=size(xin);
    dsize = sz(d);
    nn = (0:dsize-1); % vector with length equal to dsize
    kk = ((-dsize+1):(dsize-1)); % length is equal to 2*dsize-1 // length is odd and vector is centered at dsize (zero-position)
    kk2 = (kk .^ 2) ./ 2; % vector same length as kk
    
    w = exp(-2*1i*pi/(dsize*scaled)) ; % scalar factor
    a = exp(-1i*pi/scaled) ; % scalar factor
    ww = w .^ kk2; % vector same length as kk
    aa =  a.^ (-nn);
    aa = aa .* ww(dsize:end);%(dsize + nn) ; % is a 1d list of factors
    ww=dip_image(ww);
%     tofft = zeros(1,2.*dsize); 
%     tofft(1:end-1) = 1./ww;
    tofft = extract(1./ww,2.*dsize);%,dsize-1+ mod(dsize,2));
    fv = ft1d(tofft);%fft(tofft); % is always 1d
%     fak = ww( dsize-1:(2*dsize-2 )) .* exp(1i*pi*xx(dsize,1)/scaled); % is a 1d list of factors
%     expx= exp(1i*pi*xx(dsize,1)/scaled);
    fak = ww( dsize-1:end) .* exp(1i*pi*xx(dsize,1)/scaled); % is a 1d list of factors
    centerpos=@(sz) (sz-mod(sz,2))/2 ; % center position where the added mod is to account for odd values
%     xramp = nn - centerpos(dsize) ; 
%     fak = ww( dsize-1:end) .* exp(1i*pi*xramp/scaled); % is a 1d list of factors

    order = 1:length(sz);
    order( order == d ) = 1;
    order(1) = d;
    xinpermute = permute(xin,order); % change the orientation of the input image to match the dimension towards which we want the czt to run
    
    y = xinpermute*aa;
    nsz = size(xinpermute); nsz(1) = 2*sz(1); % twice the size along direction d which is along the 1st dimension since we have rotate xin
    ctrpos=centerpos(nsz);
    tofft = extract(y,nsz,ctrpos); % select region with size equal to nsz and centered at ctrpos
    g = ift1d(ft1d(tofft).*fv); % size is equal to nsz
%     g = ifft(fft(tofft).*fv); % size is equal to nsz
    
    oldctr = centerpos(sz(d)); 
    newctr = centerpos(size(g));
    newctr = newctr - mod(newctr,2) ;
    newctr(1) = newctr(1)+oldctr;% This gives symmetric output

    xout = extract(g,sz,newctr).*fak;
%     xout=extract(g,sz,centerpos(sz)).*fak;

    xout = ipermute(xout,order);

end


